import React from 'react';

function Loading({ message = "Loading..." }) {
  return <p>{message}</p>;
}

export default Loading;